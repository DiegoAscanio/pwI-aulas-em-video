<style>
    body {
        font-family: Arial, sans-serif;
        background-color: lightgray;
    }
    pre {
        width: 50%;
        margin-left: auto;
        margin-right: auto;
    }
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/atom-one-dark.min.css">
<script>hljs.highlightAll();</script>


# Rememorando CSS

Como sabemos, o CSS é uma linguagem de estilo que nos permite estilizar nossas páginas web. Com ela, podemos definir cores, fontes, tamanhos, espaçamentos, entre outras propriedades visuais.

## Usando o CSS

Para usar o CSS em nossas páginas, podemos fazer isso de três formas:

1. Dentro dos elementos (tags) HTML, usando o atributo `style`, forma esta conhecida como **CSS inline**.

    Exemplo — Colocando o texto de um parágrafo em sublinhado com a cor roxa:

        <p style="text-decoration: underline; color: purple;">Texto sublinhado em roxo</p>

2. Dentro da tag `<style>` no cabeçalho do documento HTML, forma esta conhecida como **CSS interno**.

    Exemplo — Colocando os cabeçalhos de nível 1 e 2 nas cores azul e vermelha, respectivamente:

        <html>
        <head>
            <style>
                h1 {
                    color: blue;
                }
                h2 {
                    color: red;
                }
            </style>
        </head>
        ...

3. Em um arquivo externo com extensão `.css` que é carregado através da tag link dentro do head do seu arquivo html, forma esta conhecida como **CSS externo**.

    Suponhamos que queiramos centralizar todas as imagens de múltiplas páginas. Para isso, criamos um arquivo `estilos.css` — na mesma pasta do index.html — com o seguinte conteúdo:

        img {
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

    Agora, para cada arquivo HTML que desejamos centralizar as imagens, adicionamos a seguinte linha no cabeçalho:

        <html>
        <head>
            <link rel="stylesheet" href="estilos.css">
        </head>
        </html>
